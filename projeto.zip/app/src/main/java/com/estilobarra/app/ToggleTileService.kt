package com.estilobarra.app

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Mosaico das definições rápidas para mostrar/esconder a barra (útil em jogos e vídeos). */
class ToggleTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        sync()
    }

    override fun onClick() {
        super.onClick()
        StyleStore.setShown(this, !StyleStore.isShown(this))
        BarService.instance?.refresh()
        sync()
    }

    private fun sync() {
        val t = qsTile ?: return
        t.state = if (StyleStore.isShown(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = getString(R.string.tile_label)
        t.updateTile()
    }
}
