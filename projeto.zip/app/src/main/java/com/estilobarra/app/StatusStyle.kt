package com.estilobarra.app

import android.graphics.Color
import org.json.JSONObject

/**
 * Descreve o aspeto completo da barra de estado.
 *
 * clockPos:     0 esquerda, 1 centro, 2 direita
 * batteryStyle: 0 ícone com % à esquerda, 1 pílula com número dentro (iOS),
 *               2 ícone com % à direita (Samsung), 3 só texto
 * signalStyle:  0 nenhum, 1 barras, 2 barras + 5G/4G
 * heightDp:     0 = automático (mesma altura da barra do sistema)
 */
data class StatusStyle(
    val id: String = "custom",
    val name: String = "Personalizado",
    val family: String = "custom",
    val clockPos: Int = 0,
    val clock24: Boolean = true,
    val showAmPm: Boolean = false,
    val showSeconds: Boolean = false,
    val bold: Boolean = false,
    val bgColor: Int = Color.BLACK,
    val fgColor: Int = Color.WHITE,
    val textSp: Float = 14f,
    val heightDp: Int = 0,
    val sidePadDp: Int = 14,
    val cornerDp: Int = 0,
    val gapDp: Int = 6,
    val batteryStyle: Int = 0,
    val showBatteryPercent: Boolean = true,
    val signalStyle: Int = 1,
    val showWifi: Boolean = true,
    val showNetSpeed: Boolean = false,
    val showCarrier: Boolean = false
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("family", family)
        o.put("clockPos", clockPos)
        o.put("clock24", clock24)
        o.put("showAmPm", showAmPm)
        o.put("showSeconds", showSeconds)
        o.put("bold", bold)
        o.put("bgColor", bgColor)
        o.put("fgColor", fgColor)
        o.put("textSp", textSp.toDouble())
        o.put("heightDp", heightDp)
        o.put("sidePadDp", sidePadDp)
        o.put("cornerDp", cornerDp)
        o.put("gapDp", gapDp)
        o.put("batteryStyle", batteryStyle)
        o.put("showBatteryPercent", showBatteryPercent)
        o.put("signalStyle", signalStyle)
        o.put("showWifi", showWifi)
        o.put("showNetSpeed", showNetSpeed)
        o.put("showCarrier", showCarrier)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): StatusStyle {
            val d = StatusStyle()
            return StatusStyle(
                id = o.optString("id", d.id),
                name = o.optString("name", d.name),
                family = o.optString("family", d.family),
                clockPos = o.optInt("clockPos", d.clockPos),
                clock24 = o.optBoolean("clock24", d.clock24),
                showAmPm = o.optBoolean("showAmPm", d.showAmPm),
                showSeconds = o.optBoolean("showSeconds", d.showSeconds),
                bold = o.optBoolean("bold", d.bold),
                bgColor = o.optInt("bgColor", d.bgColor),
                fgColor = o.optInt("fgColor", d.fgColor),
                textSp = o.optDouble("textSp", d.textSp.toDouble()).toFloat(),
                heightDp = o.optInt("heightDp", d.heightDp),
                sidePadDp = o.optInt("sidePadDp", d.sidePadDp),
                cornerDp = o.optInt("cornerDp", d.cornerDp),
                gapDp = o.optInt("gapDp", d.gapDp),
                batteryStyle = o.optInt("batteryStyle", d.batteryStyle),
                showBatteryPercent = o.optBoolean("showBatteryPercent", d.showBatteryPercent),
                signalStyle = o.optInt("signalStyle", d.signalStyle),
                showWifi = o.optBoolean("showWifi", d.showWifi),
                showNetSpeed = o.optBoolean("showNetSpeed", d.showNetSpeed),
                showCarrier = o.optBoolean("showCarrier", d.showCarrier)
            )
        }
    }
}

/**
 * Estilos prontos. São aproximações desenhadas por nós (não são cópias exatas
 * dos originais); depois de escolher um, podes ajustar tudo no editor.
 */
object Presets {

    val families: LinkedHashMap<String, String> = linkedMapOf(
        "oneui" to "Samsung One UI",
        "ios" to "Apple iOS",
        "hyperos" to "Xiaomi HyperOS"
    )

    private val oneBase = StatusStyle(
        family = "oneui", clockPos = 0, clock24 = true, bgColor = Color.BLACK, fgColor = Color.WHITE,
        sidePadDp = 16, gapDp = 5, batteryStyle = 2, showBatteryPercent = true,
        signalStyle = 1, showWifi = true
    )

    private val iosBase = StatusStyle(
        family = "ios", clockPos = 0, clock24 = false, showAmPm = false, bold = true,
        bgColor = Color.BLACK, fgColor = Color.WHITE, sidePadDp = 24, gapDp = 5,
        batteryStyle = 1, showBatteryPercent = true, signalStyle = 1, showWifi = true
    )

    private val miBase = StatusStyle(
        family = "hyperos", clockPos = 0, clock24 = true, bgColor = Color.BLACK, fgColor = Color.WHITE,
        sidePadDp = 16, gapDp = 5, batteryStyle = 0, showBatteryPercent = true,
        signalStyle = 2, showWifi = true, showNetSpeed = true
    )

    val all: List<StatusStyle> = listOf(
        oneBase.copy(id = "oneui61", name = "One UI 6.1", textSp = 13.5f),
        oneBase.copy(id = "oneui7", name = "One UI 7", textSp = 14f, bold = true),
        oneBase.copy(id = "oneui8", name = "One UI 8", textSp = 14.5f, bold = true),
        oneBase.copy(id = "oneui9", name = "One UI 9", textSp = 14.5f, bold = true, showNetSpeed = true),

        iosBase.copy(id = "ios15", name = "iOS 15", textSp = 15f, batteryStyle = 0, sidePadDp = 22),
        iosBase.copy(id = "ios16", name = "iOS 16", textSp = 15.5f),
        iosBase.copy(id = "ios18", name = "iOS 17 / 18", textSp = 16f),
        iosBase.copy(id = "ios26", name = "iOS 26", textSp = 16f, sidePadDp = 28),
        iosBase.copy(id = "ios27", name = "iOS 27", textSp = 16f, sidePadDp = 28),

        miBase.copy(id = "miui14", name = "MIUI 14", textSp = 13f, showCarrier = true),
        miBase.copy(id = "hyper1", name = "HyperOS 1", textSp = 13.5f),
        miBase.copy(id = "hyper2", name = "HyperOS 2", textSp = 14f, bold = true),
        miBase.copy(id = "hyper3", name = "HyperOS 3", textSp = 14f, bold = true, showNetSpeed = false),
        miBase.copy(id = "hyper31", name = "HyperOS 3.1", textSp = 14.5f, bold = true, showNetSpeed = false)
    )

    fun byFamily(f: String): List<StatusStyle> = all.filter { it.family == f }

    fun find(id: String): StatusStyle? = all.firstOrNull { it.id == id }

    fun default(): StatusStyle = find("oneui9") ?: all.first()
}
