package com.estilobarra.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Exporta o estilo para o Kustom (KLCK / KLWP / KWGT).
 *
 * Um preset do Kustom é um ficheiro zip com um "preset.json". Este exportador
 * gera um preset básico (fundo, relógio e texto da bateria). O formato interno do
 * Kustom não é documentado oficialmente, por isso esta exportação é experimental;
 * se o Kustom recusar o ficheiro, usa a "receita" (valores e fórmulas) para montar
 * a barra à mão no editor.
 */
object KlckExporter {

    private const val K = 3f // 1080 px de largura / 360 dp

    private fun hex(c: Int): String = String.format("#%08X", c)

    private fun clockExpr(st: StatusStyle): String {
        val pattern = (if (st.clock24) "HH:mm" else "h:mm") +
            (if (st.showSeconds) ":ss" else "") +
            (if (!st.clock24 && st.showAmPm) " a" else "")
        return "\$df($pattern)\$"
    }

    private fun barHeight(st: StatusStyle): Float =
        if (st.heightDp > 0) st.heightDp * K else 24f * K

    private fun textItem(
        title: String, expr: String, size: Float, color: Int,
        anchor: String, x: Float, y: Float
    ): JSONObject {
        val o = JSONObject()
        o.put("internal_type", "TextModule")
        o.put("internal_title", title)
        o.put("text_expression", expr)
        o.put("text_size", size.toInt())
        o.put("paint_color", hex(color))
        o.put("position_anchor", anchor)
        o.put("position_offset_x", x.toInt())
        o.put("position_offset_y", y.toInt())
        return o
    }

    private fun presetJson(st: StatusStyle): JSONObject {
        val barH = barHeight(st)
        val size = st.textSp * K
        val pad = st.sidePadDp * K
        val y = (barH - size * 1.2f) / 2f

        val info = JSONObject()
        info.put("version", 10)
        info.put("title", "Barra " + st.name)
        info.put("description", "Gerado pela app Estilo da Barra")
        info.put("author", "Estilo da Barra")
        info.put("email", "")
        info.put("width", 1080)
        info.put("height", 2400)
        info.put("features", 0)
        info.put("release", 0)
        info.put("locked", false)
        info.put("pflags", 0)

        val bg = JSONObject()
        bg.put("internal_type", "ShapeModule")
        bg.put("internal_title", "Fundo da barra")
        bg.put("shape_type", "RECT")
        bg.put("shape_width", 1080)
        bg.put("shape_height", barH.toInt())
        bg.put("paint_color", hex(st.bgColor))
        bg.put("position_anchor", "TOP")
        bg.put("position_offset_x", 0)
        bg.put("position_offset_y", 0)

        val clockAnchor = when (st.clockPos) {
            0 -> "TOPLEFT"
            1 -> "TOP"
            else -> "TOPRIGHT"
        }
        val clockX = when (st.clockPos) {
            0 -> pad
            1 -> 0f
            else -> -pad
        }
        val battAnchor = if (st.clockPos == 2) "TOPLEFT" else "TOPRIGHT"
        val battX = if (st.clockPos == 2) pad else -pad

        val items = JSONArray()
        items.put(bg)
        items.put(textItem("Relógio", clockExpr(st), size, st.fgColor, clockAnchor, clockX, y))
        items.put(textItem("Bateria", "\$bi(level)\$%", size * 0.9f, st.fgColor, battAnchor, battX, y))

        val root = JSONObject()
        root.put("internal_type", "RootLayerModule")
        root.put("viewgroup_items", items)

        val top = JSONObject()
        top.put("preset_info", info)
        top.put("preset_root", root)
        return top
    }

    /** Conteúdo do ficheiro .klck (zip). */
    fun build(st: StatusStyle): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            z.putNextEntry(ZipEntry("preset.json"))
            z.write(presetJson(st).toString(2).toByteArray(Charsets.UTF_8))
            z.closeEntry()
            for (d in listOf("bitmaps/", "fonts/", "icon/")) {
                z.putNextEntry(ZipEntry(d))
                z.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    /** Texto com os valores e fórmulas para montar a barra à mão no Kustom. */
    fun recipe(st: StatusStyle): String {
        val k = K.toInt()
        val barH = barHeight(st).toInt()
        val clockPos = when (st.clockPos) {
            0 -> "esquerda"
            1 -> "centro"
            else -> "direita"
        }
        val sb = StringBuilder()
        sb.append("Estilo: ").append(st.name).append("\n\n")
        sb.append("No KLCK/KLWP/KWGT cria estes objetos (tamanhos em px para 1080 de largura):\n\n")
        sb.append("1) Forma Retângulo (fundo)\n")
        sb.append("   Largura 1080, altura ").append(barH).append("\n")
        sb.append("   Cor ").append(hex(st.bgColor)).append("\n")
        sb.append("   Ancora: topo\n")
        if (st.cornerDp > 0) {
            sb.append("   Cantos de baixo arredondados: ").append(st.cornerDp * k).append("\n")
        }
        sb.append("\n2) Texto (relógio) — posição: ").append(clockPos).append("\n")
        sb.append("   Fórmula: ").append(clockExpr(st)).append("\n")
        sb.append("   Tamanho ").append((st.textSp * K).toInt())
            .append(", cor ").append(hex(st.fgColor))
            .append(if (st.bold) ", negrito" else "").append("\n")
        sb.append("   Margem lateral ").append(st.sidePadDp * k).append("\n")
        sb.append("\n3) Texto (bateria)\n")
        sb.append("   Fórmula: \$bi(level)\$%\n")
        sb.append("   Tamanho ").append((st.textSp * K * 0.9f).toInt())
            .append(", cor ").append(hex(st.fgColor)).append("\n")
        sb.append("\n4) Ícones de sinal e Wi-Fi\n")
        sb.append("   Usa Ícone de fonte (Material) ou uma Forma, com a cor ")
            .append(hex(st.fgColor)).append(".\n")
        sb.append("   Espaço entre ícones: ").append(st.gapDp * k).append("\n")
        return sb.toString()
    }
}
