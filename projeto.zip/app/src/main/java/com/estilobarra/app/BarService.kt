package com.estilobarra.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Serviço de acessibilidade usado só para ter permissão de desenhar uma janela
 * por cima da barra de estado. Não lê nem controla nada no ecrã.
 */
class BarService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BarService? = null
    }

    private var wm: WindowManager? = null
    private var view: StatusBarView? = null
    private val ui = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.post { refresh() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        removeBar()
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeBar()
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Volta a ler as opções e mostra, atualiza ou esconde a barra. */
    fun refresh() {
        val show = StyleStore.isShown(this)
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val hide = landscape && StyleStore.hideInLandscape(this)
        if (!show || hide) {
            removeBar()
            return
        }
        val style = StyleStore.load(this)
        val heightPx = if (style.heightDp > 0) {
            (style.heightDp * resources.displayMetrics.density).toInt()
        } else {
            statusBarHeightPx()
        }
        val params = buildParams(heightPx)
        val v = view
        if (v == null) {
            val nv = StatusBarView(this)
            nv.style = style
            try {
                wm?.addView(nv, params)
                view = nv
            } catch (e: Exception) {
                view = null
            }
        } else {
            v.style = style
            try {
                wm?.updateViewLayout(v, params)
            } catch (e: Exception) {
                // a janela pode já ter sido removida pelo sistema
                view = null
            }
        }
    }

    private fun buildParams(heightPx: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            heightPx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.setTitle("EstiloBarra")
        return lp
    }

    private fun removeBar() {
        val v = view ?: return
        try {
            wm?.removeViewImmediate(v)
        } catch (e: Exception) {
            // ignorar: já não estava na janela
        }
        view = null
    }
}
