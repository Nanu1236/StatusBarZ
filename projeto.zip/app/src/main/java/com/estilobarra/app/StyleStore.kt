package com.estilobarra.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/** Guarda o estilo atual e as opções simples da app. */
object StyleStore {

    private const val PREFS = "estilo_barra"

    private fun p(c: Context): SharedPreferences =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): StatusStyle {
        val s = p(c).getString("style", null) ?: return Presets.default()
        return try {
            StatusStyle.fromJson(JSONObject(s))
        } catch (e: Exception) {
            Presets.default()
        }
    }

    fun save(c: Context, st: StatusStyle) {
        p(c).edit().putString("style", st.toJson().toString()).apply()
    }

    fun isShown(c: Context): Boolean = p(c).getBoolean("shown", true)

    fun setShown(c: Context, v: Boolean) {
        p(c).edit().putBoolean("shown", v).apply()
    }

    fun hideInLandscape(c: Context): Boolean = p(c).getBoolean("hide_landscape", true)

    fun setHideInLandscape(c: Context, v: Boolean) {
        p(c).edit().putBoolean("hide_landscape", v).apply()
    }
}
