package com.estilobarra.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.TypedValue
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Altura da barra de estado real do sistema, em píxeis. */
fun Context.statusBarHeightPx(): Int {
    val id = resources.getIdentifier("status_bar_height", "dimen", "android")
    return if (id > 0) {
        resources.getDimensionPixelSize(id)
    } else {
        (24 * resources.displayMetrics.density).toInt()
    }
}

/** Barra de estado desenhada à mão (relógio, rede, Wi-Fi, bateria) segundo um [StatusStyle]. */
class StatusBarView(context: Context) : View(context) {

    var style: StatusStyle = Presets.default()
        set(value) {
            field = value
            reschedule()
            invalidate()
        }

    private val GREEN = Color.rgb(0x34, 0xC7, 0x59)
    private val RED = Color.rgb(0xFF, 0x3B, 0x30)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val bgPath = Path()
    private val boltPath = Path()
    private val handler = Handler(Looper.getMainLooper())

    private var batteryLevel = 100
    private var charging = false
    private var wifiConnected = false
    private var wifiLevel = 3
    private var cellLevel = 4
    private var netType = ""
    private var carrier = ""
    private var speedText = ""
    private var lastBytes = -1L
    private var lastTime = 0L
    private var gapPx = 0f
    private var attached = false
    private var registered = false
    private var tickCount = 0

    private var fmtPattern = ""
    private var fmt: SimpleDateFormat? = null

    private val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    // ---------------------------------------------------------------- dados do sistema

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i != null && i.action == Intent.ACTION_BATTERY_CHANGED) {
                readBattery(i)
            }
            invalidate()
        }
    }

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            wifiConnected = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            if (wifiConnected && Build.VERSION.SDK_INT >= 29) {
                val ss = caps.signalStrength
                if (ss != NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) {
                    @Suppress("DEPRECATION")
                    wifiLevel = WifiManager.calculateSignalLevel(ss, 4)
                }
            }
            pollPhone()
            postInvalidate()
        }

        override fun onLost(network: Network) {
            wifiConnected = false
            postInvalidate()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            tickCount++
            if (style.showNetSpeed) updateSpeed()
            if (tickCount % 10 == 0 || !fast()) pollPhone()
            invalidate()
            handler.postDelayed(this, if (fast()) 1000L else 15000L)
        }
    }

    private fun fast(): Boolean = style.showSeconds || style.showNetSpeed

    private fun reschedule() {
        handler.removeCallbacks(ticker)
        if (attached) handler.post(ticker)
    }

    private fun readBattery(i: Intent) {
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (l >= 0 && s > 0) batteryLevel = l * 100 / s
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun pollPhone() {
        try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return
            carrier = tm.networkOperatorName ?: ""
            if (Build.VERSION.SDK_INT >= 28) {
                val ss = tm.signalStrength
                if (ss != null) cellLevel = ss.level
            }
            netType = try {
                when (tm.dataNetworkType) {
                    TelephonyManager.NETWORK_TYPE_NR -> "5G"
                    TelephonyManager.NETWORK_TYPE_LTE -> "4G"
                    TelephonyManager.NETWORK_TYPE_UNKNOWN -> ""
                    else -> "3G"
                }
            } catch (t: Throwable) {
                ""
            }
        } catch (t: Throwable) {
            // sem permissão de telefone: mantém os valores por omissão
        }
    }

    private fun updateSpeed() {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0 || tx < 0) {
            speedText = ""
            return
        }
        val total = rx + tx
        val now = SystemClock.elapsedRealtime()
        if (lastBytes >= 0 && now > lastTime) {
            var bps = (total - lastBytes) * 1000.0 / (now - lastTime)
            if (bps < 0) bps = 0.0
            speedText = fmtSpeed(bps)
        }
        lastBytes = total
        lastTime = now
    }

    private fun fmtSpeed(b: Double): String = when {
        b < 1000.0 -> String.format(Locale.US, "%.0f B/s", b)
        b < 1024.0 * 1024.0 -> String.format(Locale.US, "%.1f KB/s", b / 1024.0)
        else -> String.format(Locale.US, "%.1f MB/s", b / (1024.0 * 1024.0))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        if (!registered) {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_BATTERY_CHANGED)
            f.addAction(Intent.ACTION_TIME_TICK)
            f.addAction(Intent.ACTION_TIME_CHANGED)
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED)
            val sticky = if (Build.VERSION.SDK_INT >= 33) {
                context.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, f)
            }
            if (sticky != null) readBattery(sticky)
            try {
                cm.registerDefaultNetworkCallback(netCb)
            } catch (e: Exception) {
                // sem acesso ao estado de rede
            }
            registered = true
        }
        pollPhone()
        reschedule()
    }

    override fun onDetachedFromWindow() {
        attached = false
        handler.removeCallbacks(ticker)
        if (registered) {
            try {
                context.unregisterReceiver(receiver)
            } catch (e: Exception) {
            }
            try {
                cm.unregisterNetworkCallback(netCb)
            } catch (e: Exception) {
            }
            registered = false
        }
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- utilitários de desenho

    private fun dpf(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private fun spf(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private fun withAlpha(color: Int, a: Int): Int {
        val na = a * Color.alpha(color) / 255
        return Color.argb(na, Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun contrast(color: Int): Int {
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return if (lum > 0.55) Color.BLACK else Color.WHITE
    }

    private fun setText(size: Float, bold: Boolean, alpha: Int) {
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.textSize = size
        textPaint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        textPaint.color = withAlpha(style.fgColor, alpha)
    }

    private fun drawText(
        c: Canvas, s: String, x: Float, cy: Float, size: Float, alpha: Int,
        bold: Boolean = style.bold
    ): Float {
        setText(size, bold, alpha)
        val fm = textPaint.fontMetrics
        c.drawText(s, x, cy - (fm.ascent + fm.descent) / 2f, textPaint)
        return textPaint.measureText(s)
    }

    private fun measureText(s: String, size: Float, bold: Boolean): Float {
        setText(size, bold, 255)
        return textPaint.measureText(s)
    }

    private fun clockText(): String {
        val st = style
        val pattern = (if (st.clock24) "HH:mm" else "h:mm") +
            (if (st.showSeconds) ":ss" else "") +
            (if (!st.clock24 && st.showAmPm) " a" else "")
        var f = fmt
        if (f == null || pattern != fmtPattern) {
            f = SimpleDateFormat(pattern, Locale.getDefault())
            fmt = f
            fmtPattern = pattern
        }
        return f.format(Date())
    }

    // ---------------------------------------------------------------- ícones

    private fun batteryTextW(u: Float): Float = measureText("$batteryLevel%", u * 0.9f, style.bold)

    private fun batteryWidth(u: Float): Float {
        val st = style
        val nub = u * 0.12f
        val inner = u * 0.25f
        return when (st.batteryStyle) {
            1 -> u * 1.9f + nub
            3 -> batteryTextW(u)
            2 -> u * 1.55f + nub + (if (st.showBatteryPercent) inner + batteryTextW(u) else 0f)
            else -> (if (st.showBatteryPercent) batteryTextW(u) + inner else 0f) + u * 1.55f + nub
        }
    }

    private fun drawBattery(c: Canvas, x0: Float, cy: Float, u: Float) {
        val st = style
        val nub = u * 0.12f
        val inner = u * 0.25f
        val txt = "$batteryLevel%"
        when (st.batteryStyle) {
            3 -> drawText(c, txt, x0, cy, u * 0.9f, 255)
            1 -> drawBatteryIcon(c, x0, cy, u * 1.9f, u * 1.0f, u, true, st.showBatteryPercent)
            2 -> {
                drawBatteryIcon(c, x0, cy, u * 1.55f, u * 0.78f, u, false, false)
                if (st.showBatteryPercent) {
                    drawText(c, txt, x0 + u * 1.55f + nub + inner, cy, u * 0.9f, 255)
                }
            }
            else -> {
                var x = x0
                if (st.showBatteryPercent) {
                    drawText(c, txt, x, cy, u * 0.9f, 255)
                    x += batteryTextW(u) + inner
                }
                drawBatteryIcon(c, x, cy, u * 1.55f, u * 0.78f, u, false, false)
            }
        }
    }

    private fun drawBatteryIcon(
        c: Canvas, left: Float, cy: Float, bw: Float, bh: Float, u: Float,
        pill: Boolean, number: Boolean
    ) {
        val st = style
        val top = cy - bh / 2f
        val radius = bh * (if (pill) 0.42f else 0.22f)
        val stroke = u * 0.07f

        // contorno
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.color = withAlpha(st.fgColor, 110)
        rect.set(left + stroke / 2f, top + stroke / 2f, left + bw - stroke / 2f, top + bh - stroke / 2f)
        c.drawRoundRect(rect, radius, radius, paint)

        // ponta
        paint.style = Paint.Style.FILL
        rect.set(left + bw + u * 0.03f, cy - bh * 0.18f, left + bw + u * 0.12f, cy + bh * 0.18f)
        c.drawRoundRect(rect, u * 0.04f, u * 0.04f, paint)

        // enchimento
        val inset = stroke + u * 0.04f
        val full = bw - 2f * inset
        val fw = (full * batteryLevel / 100f).coerceAtLeast(u * 0.06f)
        val fillColor = when {
            charging -> GREEN
            batteryLevel <= 15 -> RED
            else -> st.fgColor
        }
        paint.color = fillColor
        rect.set(left + inset, top + inset, left + inset + fw, top + bh - inset)
        val fr = radius * 0.7f
        c.drawRoundRect(rect, fr, fr, paint)

        if (number) {
            val tcol = if (batteryLevel >= 50) contrast(fillColor) else contrast(st.bgColor)
            val size = if (batteryLevel >= 100) u * 0.62f else u * 0.78f
            textPaint.reset()
            textPaint.isAntiAlias = true
            textPaint.textSize = size
            textPaint.typeface = Typeface.DEFAULT_BOLD
            textPaint.color = tcol
            val s = "$batteryLevel"
            val tw = textPaint.measureText(s)
            val fm = textPaint.fontMetrics
            c.drawText(s, left + bw / 2f - tw / 2f, cy - (fm.ascent + fm.descent) / 2f, textPaint)
        } else if (charging) {
            val cx = left + bw / 2f
            boltPath.reset()
            boltPath.moveTo(cx + 0.15f * u, cy - 0.38f * u)
            boltPath.lineTo(cx - 0.20f * u, cy + 0.05f * u)
            boltPath.lineTo(cx - 0.02f * u, cy + 0.05f * u)
            boltPath.lineTo(cx - 0.12f * u, cy + 0.38f * u)
            boltPath.lineTo(cx + 0.22f * u, cy - 0.08f * u)
            boltPath.lineTo(cx + 0.04f * u, cy - 0.08f * u)
            boltPath.close()
            paint.color = contrast(st.bgColor)
            c.drawPath(boltPath, paint)
        }
    }

    private fun drawSignal(c: Canvas, x: Float, cy: Float, u: Float) {
        val barW = u * 0.2f
        val barGap = u * 0.1f
        val maxH = u * 0.8f
        val bottom = cy + maxH / 2f
        for (i in 0..3) {
            val bh = maxH * (0.4f + 0.2f * i)
            val left = x + i * (barW + barGap)
            paint.reset()
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            paint.color = withAlpha(style.fgColor, if (i < cellLevel) 255 else 90)
            rect.set(left, bottom - bh, left + barW, bottom)
            c.drawRoundRect(rect, barW * 0.3f, barW * 0.3f, paint)
        }
    }

    private fun drawWifi(c: Canvas, x: Float, cy: Float, u: Float) {
        val px = x + u * 0.65f
        val py = cy + u * 0.4f
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = u * 0.14f
        for (i in 1..3) {
            val r = u * 0.3f * i
            paint.color = withAlpha(style.fgColor, if (i <= wifiLevel) 255 else 90)
            rect.set(px - r, py - r, px + r, py + r)
            c.drawArc(rect, 225f, 90f, false, paint)
        }
        paint.style = Paint.Style.FILL
        paint.color = style.fgColor
        c.drawCircle(px, py - u * 0.02f, u * 0.09f, paint)
    }

    /**
     * Desenha (ou só mede, se [c] for nulo) o grupo de ícones: tipo de rede, sinal,
     * Wi-Fi e bateria. Devolve a largura total.
     */
    private fun icons(c: Canvas?, x0: Float, cy: Float, u: Float): Float {
        val st = style
        var x = x0
        var first = true

        fun place(w: Float, draw: (Float) -> Unit) {
            if (w <= 0f) return
            if (!first) x += gapPx
            if (c != null) draw(x)
            x += w
            first = false
        }

        if (st.signalStyle == 2 && netType.isNotEmpty()) {
            val w = measureText(netType, u * 0.8f, true)
            place(w) { px -> if (c != null) drawText(c, netType, px, cy, u * 0.8f, 255, true) }
        }
        if (st.signalStyle >= 1) {
            place(u * 1.1f) { px -> if (c != null) drawSignal(c, px, cy, u) }
        }
        if (st.showWifi && wifiConnected) {
            place(u * 1.3f) { px -> if (c != null) drawWifi(c, px, cy, u) }
        }
        place(batteryWidth(u)) { px -> if (c != null) drawBattery(c, px, cy, u) }

        return x - x0
    }

    private fun drawExtras(c: Canvas, x0: Float, cy: Float, u: Float): Float {
        var x = x0
        val st = style
        if (st.showNetSpeed && speedText.isNotEmpty()) {
            x += drawText(c, speedText, x, cy, u * 0.72f, 210) + gapPx
        }
        if (st.showCarrier && carrier.isNotEmpty()) {
            x += drawText(c, carrier, x, cy, u * 0.72f, 210) + gapPx
        }
        return x
    }

    // ---------------------------------------------------------------- desenho principal

    override fun onDraw(canvas: Canvas) {
        val st = style
        val w = width.toFloat()
        val h = height.toFloat()

        // fundo
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = st.bgColor
        if (st.cornerDp > 0) {
            val r = dpf(st.cornerDp.toFloat())
            bgPath.reset()
            bgPath.addRoundRect(
                0f, 0f, w, h,
                floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r),
                Path.Direction.CW
            )
            canvas.drawPath(bgPath, paint)
        } else {
            canvas.drawRect(0f, 0f, w, h, paint)
        }

        val u = spf(st.textSp)
        val pad = dpf(st.sidePadDp.toFloat())
        gapPx = dpf(st.gapDp.toFloat())
        val cy = h / 2f

        val clock = clockText()
        val clockW = measureText(clock, u, st.bold)
        val iconsW = icons(null, 0f, cy, u)

        when (st.clockPos) {
            0 -> {
                drawText(canvas, clock, pad, cy, u, 255)
                drawExtras(canvas, pad + clockW + gapPx * 1.5f, cy, u)
                icons(canvas, w - pad - iconsW, cy, u)
            }
            1 -> {
                drawText(canvas, clock, (w - clockW) / 2f, cy, u, 255)
                drawExtras(canvas, pad, cy, u)
                icons(canvas, w - pad - iconsW, cy, u)
            }
            else -> {
                drawText(canvas, clock, w - pad - clockW, cy, u, 255)
                icons(canvas, pad, cy, u)
                drawExtras(canvas, pad + iconsW + gapPx * 1.5f, cy, u)
            }
        }
    }
}
