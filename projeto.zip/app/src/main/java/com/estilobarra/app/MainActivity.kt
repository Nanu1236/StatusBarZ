package com.estilobarra.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val REQ_KLCK = 11
    private val REQ_JSON_EXPORT = 12
    private val REQ_JSON_IMPORT = 13
    private val REQ_PHONE = 14

    private val cBg = Color.rgb(0x0E, 0x0E, 0x12)
    private val cCard = Color.rgb(0x1B, 0x1B, 0x24)
    private val cAccent = Color.rgb(0xFF, 0x2D, 0x4D)
    private val cMuted = Color.rgb(0xA0, 0xA0, 0xB0)

    private lateinit var style: StatusStyle
    private lateinit var preview: StatusBarView
    private lateinit var editor: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var currentView: TextView

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        style = StyleStore.load(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(cBg)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(12), dp(16), dp(40))
        scroll.addView(root)
        setContentView(scroll)

        root.addView(tv("Estilo da Barra", 26f, Color.WHITE, true))
        root.addView(tv("Muda o aspeto da barra de estado: One UI, iOS, HyperOS ou o teu próprio estilo.", 13f, cMuted))

        // Pré-visualização
        val prevCard = addCard(root)
        prevCard.addView(title("Pré-visualização"))
        preview = StatusBarView(this)
        preview.style = style
        prevCard.addView(preview, LinearLayout.LayoutParams(MATCH, previewHeight()))
        currentView = tv("Estilo atual: " + style.name, 13f, cMuted)
        prevCard.addView(currentView)

        // Estilos prontos
        val presetCard = addCard(root)
        presetCard.addView(title("Estilos prontos"))
        for ((fid, fname) in Presets.families) {
            presetCard.addView(tv(fname, 13f, cMuted))
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (p in Presets.byFamily(fid)) row.addView(chip(p))
            hs.addView(row)
            presetCard.addView(hs)
        }
        presetCard.addView(tv("São aproximações feitas por nós, não cópias exatas. Depois de escolher, ajusta tudo em baixo.", 12f, cMuted))

        // Serviço
        val svcCard = addCard(root)
        svcCard.addView(title("Ativar a barra"))
        statusView = tv("", 14f)
        svcCard.addView(statusView)
        svcCard.addView(button("Abrir definições de Acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        svcCard.addView(tv(
            "Procura \"Estilo da Barra\" em Aplicações instaladas e ativa. " +
                "Se aparecer cinzento (Android 13+): Definições > Aplicações > Estilo da Barra > menu ⋮ > Permitir definições restritas.",
            12f, cMuted
        ))
        svcCard.addView(sw("Mostrar a barra personalizada", StyleStore.isShown(this)) { v ->
            StyleStore.setShown(this, v)
            BarService.instance?.refresh()
        })
        svcCard.addView(sw("Esconder em modo paisagem (jogos e vídeos)", StyleStore.hideInLandscape(this)) { v ->
            StyleStore.setHideInLandscape(this, v)
            BarService.instance?.refresh()
        })
        svcCard.addView(button("Permitir leitura do sinal da rede") {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), REQ_PHONE)
        })
        svcCard.addView(tv(
            "Dica: adiciona o mosaico \"Barra personalizada\" às definições rápidas para ligar e desligar num toque.",
            12f, cMuted
        ))

        // Editor
        editor = LinearLayout(this)
        editor.orientation = LinearLayout.VERTICAL
        root.addView(editor)
        rebuildEditor()

        // Exportar
        val expCard = addCard(root)
        expCard.addView(title("Exportar e importar"))
        expCard.addView(button("Exportar para KLCK (.klck)") {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "application/octet-stream"
            i.putExtra(Intent.EXTRA_TITLE, "estilo_barra.klck")
            startActivityForResult(i, REQ_KLCK)
        })
        expCard.addView(button("Ver receita para o Kustom (valores e fórmulas)") { showRecipe() })
        expCard.addView(button("Exportar estilo (.json)") {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "application/json"
            i.putExtra(Intent.EXTRA_TITLE, "estilo_barra.json")
            startActivityForResult(i, REQ_JSON_EXPORT)
        })
        expCard.addView(button("Importar estilo (.json)") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, REQ_JSON_IMPORT)
        })
        expCard.addView(tv(
            "Importar no Kustom: abre o KLCK, toca em importar e escolhe o ficheiro .klck. " +
                "A exportação é experimental; se o Kustom recusar, usa a receita.",
            12f, cMuted
        ))
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        if (BarService.instance != null) {
            statusView.text = "● Serviço ativo"
            statusView.setTextColor(Color.rgb(0x34, 0xC7, 0x59))
        } else {
            statusView.text = "○ Serviço desativado"
            statusView.setTextColor(cAccent)
        }
    }

    // ---------------------------------------------------------------- estilo

    private fun previewHeight(): Int =
        if (style.heightDp > 0) dp(style.heightDp) else statusBarHeightPx()

    private fun commit(n: StatusStyle, rebuild: Boolean) {
        style = n
        StyleStore.save(this, n)
        preview.style = n
        preview.layoutParams = LinearLayout.LayoutParams(MATCH, previewHeight())
        currentView.text = "Estilo atual: " + n.name
        BarService.instance?.refresh()
        if (rebuild) rebuildEditor()
    }

    private fun edit(f: (StatusStyle) -> StatusStyle) {
        val n = f(style)
        val name = if (n.name.endsWith("(editado)")) n.name else n.name + " (editado)"
        commit(n.copy(name = name), false)
    }

    private fun rebuildEditor() {
        editor.removeAllViews()
        val st = style

        // Relógio
        val c1 = addCard(editor)
        c1.addView(title("Relógio"))
        c1.addView(radios(listOf("À esquerda", "Ao centro", "À direita"), st.clockPos) { v ->
            edit { it.copy(clockPos = v) }
        })
        c1.addView(sw("Formato de 24 horas", st.clock24) { v -> edit { it.copy(clock24 = v) } })
        c1.addView(sw("Mostrar AM/PM (formato de 12 horas)", st.showAmPm) { v -> edit { it.copy(showAmPm = v) } })
        c1.addView(sw("Mostrar segundos", st.showSeconds) { v -> edit { it.copy(showSeconds = v) } })
        c1.addView(sw("Texto em negrito", st.bold) { v -> edit { it.copy(bold = v) } })

        // Ícones
        val c2 = addCard(editor)
        c2.addView(title("Bateria"))
        c2.addView(radios(
            listOf("Ícone, % à esquerda", "Pílula com número dentro (iOS)", "Ícone, % à direita", "Só texto"),
            st.batteryStyle
        ) { v -> edit { it.copy(batteryStyle = v) } })
        c2.addView(sw("Mostrar percentagem", st.showBatteryPercent) { v -> edit { it.copy(showBatteryPercent = v) } })

        val c3 = addCard(editor)
        c3.addView(title("Rede"))
        c3.addView(radios(listOf("Sem sinal", "Barras de sinal", "Barras + 5G/4G"), st.signalStyle) { v ->
            edit { it.copy(signalStyle = v) }
        })
        c3.addView(sw("Mostrar Wi-Fi", st.showWifi) { v -> edit { it.copy(showWifi = v) } })
        c3.addView(sw("Mostrar velocidade da rede", st.showNetSpeed) { v -> edit { it.copy(showNetSpeed = v) } })
        c3.addView(sw("Mostrar nome da operadora", st.showCarrier) { v -> edit { it.copy(showCarrier = v) } })

        // Tamanho e forma
        val c4 = addCard(editor)
        c4.addView(title("Tamanho e forma"))
        c4.addView(slider("Tamanho do texto", 10, 24, st.textSp.toInt(), { "$it sp" }) { v ->
            edit { it.copy(textSp = v.toFloat()) }
        })
        c4.addView(slider("Altura da barra", 0, 64, st.heightDp, { if (it == 0) "automática" else "$it dp" }) { v ->
            edit { it.copy(heightDp = v) }
        })
        c4.addView(slider("Margem lateral", 0, 48, st.sidePadDp, { "$it dp" }) { v ->
            edit { it.copy(sidePadDp = v) }
        })
        c4.addView(slider("Espaço entre ícones", 2, 20, st.gapDp, { "$it dp" }) { v ->
            edit { it.copy(gapDp = v) }
        })
        c4.addView(slider("Cantos de baixo arredondados", 0, 28, st.cornerDp, { "$it dp" }) { v ->
            edit { it.copy(cornerDp = v) }
        })

        // Cores
        val c5 = addCard(editor)
        c5.addView(title("Cores"))
        c5.addView(colorRow(
            "Fundo (usa uma cor sem transparência para tapar a barra original)",
            st.bgColor,
            intArrayOf(
                Color.BLACK, Color.rgb(0x12, 0x12, 0x12), Color.rgb(0x1C, 0x1C, 0x1E),
                Color.rgb(0x2A, 0x0A, 0x10), Color.WHITE, Color.rgb(0xFF, 0x17, 0x44)
            )
        ) { c -> edit { it.copy(bgColor = c) } })
        c5.addView(colorRow(
            "Texto e ícones",
            st.fgColor,
            intArrayOf(
                Color.WHITE, Color.BLACK, Color.rgb(0xFF, 0x2D, 0x4D),
                Color.rgb(0x00, 0xE6, 0x76), Color.rgb(0xFF, 0xEA, 0x00), Color.rgb(0x40, 0xC4, 0xFF)
            )
        ) { c -> edit { it.copy(fgColor = c) } })
    }

    // ---------------------------------------------------------------- exportar / importar

    private fun showRecipe() {
        val text = KlckExporter.recipe(style)
        AlertDialog.Builder(this)
            .setTitle("Receita para o Kustom")
            .setMessage(text)
            .setPositiveButton("Copiar") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("receita", text))
                toast("Copiado")
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            when (requestCode) {
                REQ_KLCK -> {
                    contentResolver.openOutputStream(uri)?.use { it.write(KlckExporter.build(style)) }
                    toast("Ficheiro .klck guardado")
                }
                REQ_JSON_EXPORT -> {
                    contentResolver.openOutputStream(uri)?.use {
                        it.write(style.toJson().toString(2).toByteArray(Charsets.UTF_8))
                    }
                    toast("Estilo guardado")
                }
                REQ_JSON_IMPORT -> {
                    val txt = contentResolver.openInputStream(uri)?.use {
                        it.readBytes().toString(Charsets.UTF_8)
                    }
                    if (txt != null) {
                        commit(StatusStyle.fromJson(JSONObject(txt)), true)
                        toast("Estilo importado")
                    }
                }
            }
        } catch (e: Exception) {
            toast("Erro: " + e.message)
        }
    }

    // ---------------------------------------------------------------- construção da interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun tv(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, dp(2), 0, dp(2))
        return t
    }

    private fun title(s: String): TextView = tv(s, 16f, cAccent, true)

    private fun addCard(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val d = GradientDrawable()
        d.setColor(cCard)
        d.cornerRadius = dp(16).toFloat()
        c.background = d
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(12)
        parent.addView(c, lp)
        return c
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val d = GradientDrawable()
        d.setColor(cAccent)
        d.cornerRadius = dp(12).toFloat()
        b.background = d
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(8)
        b.layoutParams = lp
        return b
    }

    private fun chip(p: StatusStyle): TextView {
        val t = tv(p.name, 14f)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        val d = GradientDrawable()
        d.setColor(Color.rgb(0x2A, 0x2A, 0x36))
        d.cornerRadius = dp(18).toFloat()
        t.background = d
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(0, dp(6), dp(8), dp(10))
        t.layoutParams = lp
        t.setOnClickListener { commit(p, true) }
        return t
    }

    private fun sw(label: String, on: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = label
        s.setTextColor(Color.WHITE)
        s.isChecked = on
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        return s
    }

    private fun radios(options: List<String>, selected: Int, onSel: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.VERTICAL
        val ids = options.map { View.generateViewId() }
        for (i in options.indices) {
            val rb = RadioButton(this)
            rb.id = ids[i]
            rb.text = options[i]
            rb.setTextColor(Color.WHITE)
            g.addView(rb)
        }
        g.check(ids[selected.coerceIn(0, options.size - 1)])
        g.setOnCheckedChangeListener { _, id ->
            val i = ids.indexOf(id)
            if (i >= 0) onSel(i)
        }
        return g
    }

    private fun slider(
        label: String, min: Int, max: Int, value: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(2))
        val t = tv(label + ": " + fmt(value), 14f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (value - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                t.text = label + ": " + fmt(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(t)
        box.addView(sb)
        return box
    }

    private fun colorToHex(c: Int): String = String.format("#%08X", c)

    private fun colorRow(titleText: String, current: Int, swatches: IntArray, onPick: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, dp(4))
        box.addView(tv(titleText, 14f))

        val hex = EditText(this)
        hex.setText(colorToHex(current))
        hex.setTextColor(Color.WHITE)
        hex.setSingleLine()
        hex.hint = "#RRGGBB"

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (c in swatches) {
            val v = View(this)
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(c)
            d.setStroke(dp(2), Color.GRAY)
            v.background = d
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(0, dp(6), dp(10), dp(6))
            v.layoutParams = lp
            v.setOnClickListener {
                hex.setText(colorToHex(c))
                onPick(c)
            }
            row.addView(v)
        }
        box.addView(row)

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f))
        val ok = Button(this)
        ok.text = "Aplicar"
        ok.isAllCaps = false
        ok.setOnClickListener {
            try {
                onPick(Color.parseColor(hex.text.toString().trim()))
            } catch (e: Exception) {
                toast("Cor inválida")
            }
        }
        line.addView(ok, LinearLayout.LayoutParams(WRAP, WRAP))
        box.addView(line)
        return box
    }
}
